
#include <stdio.h>

int main()
{
    printf("Hello Arleen!");
    return 0;
}